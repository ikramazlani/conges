package com.helloIftekhar.springJwt.model;

public enum Role {
    USER,
    ADMIN
}
